<?php
// credentials.php

$credentials = [
    'token'=>'ISSecretKey_test_7d5d1b67-d780-4c9a-856a-d9b49e6328dc',
    'publishable_key'=>'ISPubKey_test_25de78f5-9274-4a51-8f9f-a5986d87e93a'
];